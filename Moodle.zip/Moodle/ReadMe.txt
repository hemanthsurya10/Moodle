------------------------------------------------------------------------------------------------README-------------------------------------------------------------------------------------------------------
1.Open Register_form.html to Register user///////////
(After registering)

Admin:
1. Login as admin through login.html(username = admin and password = 123456)
2. Add some courses from Add courses option.
3. Add registered instructor to available courses.
------OPTIONS----
4. Remove instructors using Remove instructor option.
5. Remove courses using Remove course option.
6. Remove users using remove user option.
7. Receives complaints from users. 

Instructors:
1. Go to any one of the courses.
2. In Assignments you are able to post assignments.
3. You'll be able to evaluate assignments and grade after some students have submitted.
4.Set paper to give test for students.
5.Dicuss topics in discussion forum.

Students:
1. Enroll to offered courses using add_students_form.php////////
2. Login through login.html
3. Complete assignments and submit using submit option
4.Take test hosted by instructor.
5.Discuss topics in discussion forum.