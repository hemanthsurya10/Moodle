<html>
<head>
<title>
    Deny user permission
</title>
</head>
<body>
    <div id="container">
    <h2>Deny user permission</h2>
    <form id="remove_user" action="remove_user.php"  method="post" enctype="multipart/form-data"  >
        By registered user ID
        <input type="text" name="user_id"/></br>
       
        <input type="submit">
    </form>
    </div>
</body>

</html>