<html>
<head>
<title>
    Remove instructor
</title>
</head>
<body>
    <div id="container">
    <form id="remove_instructors" action="remove_ins.php"  method="post" enctype="multipart/form-data"  >
    Registered user ID
        <input type="text" name="user_id"/></br>
        <input type="submit">
    </form>
    </div>
</body>

</html>